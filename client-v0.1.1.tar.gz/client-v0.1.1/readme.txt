
srun300 client for Henan University of Techonlogy


----------安装: -----------
	windows用户下载client.zip,解压至任意位置即可.
	linux用户下载client.tar.gz,解压至任意位置.

----------运行:---------------
	windows用户请直接运行client.exe.
注意: 无法运行的请自行安装jre或jdk. 也可以直接将jre解压至安装目录.

	linux用户请使用如下命令: java -jar client.jar
主要: 无法运行请自行安装jre或jdk.

----------建立快捷方式----------
	windows用户请直接将client.exe发送至桌面快捷方式即可.
	linux用户请用vi / vim / gedit 等编辑器打开client.desktop文件进行编辑。
例如：client的安装目录为/home/abc/client
	1. 将Exec=行修改为:
	Exec=java -jar /home/abc/client/client.jar

	2. 将Icon=行修改为:
	Icon=/home/abc/client/logo128.png

	3. 将编辑后的文件复制至自己的桌面

注意: 所以的修改必须是用户自己的情况而定。

如有疑问请邮件:szq921@gmail.com
